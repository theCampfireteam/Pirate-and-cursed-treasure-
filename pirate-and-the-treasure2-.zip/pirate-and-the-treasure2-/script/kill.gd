extends Area2D

func _ready():
	# ربط إشارة الاصطدام فاش يدخل شي جسم وسط الشوك
	body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node2D):
	# تأكد أن الجسم اللي قاص الشوك هو اللاعب
	if body.name == "Player":
		# إذا كان فيه دالة الـ respawn، عيط عليها باش يرجع للشيك بوينت
		if body.has_method("respawn"):
			body.respawn()
