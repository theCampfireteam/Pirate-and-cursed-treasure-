extends CharacterBody2D
class_name player
const SPEED = 300.0
const JUMP_VELOCITY = -400.0

@onready var attacking = false 
@onready var animation_player = $AnimationPlayer
@onready var sprite_2d = $Sprite2D


func _physics_process(delta):

		
	if not is_on_floor():
		velocity += get_gravity() * delta

	
	if Input.is_action_just_pressed("ui_accept") and is_on_floor():
		velocity.y = JUMP_VELOCITY
		
		animation_player.play("jump2")

	
	var direction := Input.get_axis("ui_left", "ui_right")
	if direction and attacking ==false:
		velocity.x = direction * SPEED
		
		sprite_2d.flip_h = direction < 0
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)

	update_animations(direction)
	move_and_slide()
	
	
	

func update_animations(direction):
	if is_on_floor() :
		
		if direction == 0 and attacking == false:
			animation_player.play("idle")
		else:
			animation_player.play("run")
	else:
		if Input.is_action_pressed ("attack"):
			animation_player.play("air_attack")
		if velocity.y < 0 and attacking == false:
			animation_player.play("jump2")
		else :
			animation_player.play("fall") 
func respawn():
	if Gamemanagar.last_checkpoint_position != Vector2.ZERO:
		global_position = Gamemanagar.last_checkpoint_position
	else:
		
		get_tree().reload_current_scene()
		
	velocity = Vector2.ZERO
