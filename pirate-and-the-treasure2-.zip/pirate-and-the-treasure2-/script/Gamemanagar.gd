extends Node

# إحداثيات آخر شيك بوينت وصل ليه اللاعب
var last_checkpoint_position: Vector2 = Vector2.ZERO

# إشارة (Signal) كتعلم السيستيم بلي الشيك بوينت تبدل
signal checkpoint_activated(pos: Vector2)

func _ready():
	# ربط الإشارة مع دالة التحديث
	checkpoint_activated.connect(_on_checkpoint_activated)

func _on_checkpoint_activated(pos: Vector2):
	last_checkpoint_position = pos
