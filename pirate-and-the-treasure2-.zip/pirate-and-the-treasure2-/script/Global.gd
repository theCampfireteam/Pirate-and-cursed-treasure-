extends Node

# يحفظ آخر موقع وصل له اللاعب 
var last_checkpoint_pos: Vector2 = Vector2.ZERO
func _update_position(new_position): 
	last_checkpoint_pos = new_position
