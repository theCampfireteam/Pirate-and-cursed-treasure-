extends Node2D

#نود الانيميشن
@onready var anim: AnimationPlayer = $AnimationPlayer


var is_active: bool = false

func _ready() -> void:
	anim.play("activatede")
#ليس اول واحدة خطأ بل الخامسة في الاشارات signals
func _on_area_2d_body_entered(body: Node2D) -> void:
	# التأكد من أن اللاعب دخل للشيك بوينت
	if body.is_in_group("Player") and not is_active:
		is_active = true
		# تحديث الموقع في العقدة العامة
		Global.last_checkpoint_pos = global_position
		#Global هو كود عالمي يسمح بناداته في كل المراحل مثل الكوين عندمايكون في المرحلة الاولى يكون مثلا 5 
		#وفي المرحلة الثانية صفر لانك ما تقدر تنقل الكوين او الشيك بوينت الى كل لاعب موجود في مرحلة واذا ما فهمت كلمني
