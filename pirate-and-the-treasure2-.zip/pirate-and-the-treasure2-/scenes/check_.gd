extends Area2D

# ربط نود الأنيميشن بالسكريبت
@onready var anim = $AnimationPlayer

var is_active: bool = false

func _ready():
	anim.play("activate")
	# ربط إشارة دخول اللاعب
	body_entered.connect(_on_body_entered)
	# تشغيل أنيميشن الحالة العادية فالبدية

func _on_body_entered(body: Node2D):
	# تأكد أن اللاعب هو اللي دخل وأن الشيك بوينت مازال مأكتيفاش
	if body.name == "Player" and not is_active:
		is_active = true
		
		# إرسال الإحداثيات للـ GameManager
		Gamemanagar.checkpoint_activated.emit(global_position)
		
		# تشغيل أنيميشن التفعيل
		
		print("Checkpoint Activated with Animation!")

	
