extends Node


var current_checkpoint : checkpoint

var Player = CharacterBody2D

func respawn_player():
	if current_checkpoint != null :
		Player.positoin = current_checkpoint.global_position
	
